public interface Object {

    void move(int x, int y);
    void moveTo(int x, int y);
    void draw();
    void erase();
    void changeColor(String color);
    void inflate(int refX, int refY, double factor);

}

